import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Activity, Heart, Droplets, User, Download, Plus } from 'lucide-react';
import { toast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';

interface SinalVital {
  id: string;
  data_hora: string;
  gmus: string;
  pressao: string;
  hgt: string;
  profissional: string;
  created_at?: string;
  updated_at?: string;
}

interface SinalVitalDB {
  id: string;
  data_hora: string;
  gmus: string;
  pressao: string;
  hgt: string;
  profissional: string;
  created_at: string;
  updated_at: string;
}

const Index = () => {
  const [sinaisVitais, setSinaisVitais] = useState<SinalVital[]>([]);
  const [formData, setFormData] = useState({
    gmus: '',
    pressao: '',
    hgt: '',
    profissional: ''
  });

  // Carregar dados do Supabase ao inicializar
  useEffect(() => {
    carregarDados();
  }, []);

  const carregarDados = async () => {
    try {
      const { data, error } = await (supabase as any)
        .from('sinais_vitais')
        .select('*')
        .order('data_hora', { ascending: false });

      if (error) {
        console.error('Erro ao carregar dados:', error);
        toast({
          title: "Erro",
          description: "Erro ao carregar dados do banco.",
          variant: "destructive"
        });
        return;
      }

      const dadosFormatados = data?.map((item: any) => ({
        id: item.id,
        data_hora: new Date(item.data_hora).toLocaleString('pt-BR'),
        gmus: item.gmus,
        pressao: item.pressao,
        hgt: item.hgt,
        profissional: item.profissional,
        created_at: item.created_at,
        updated_at: item.updated_at
      })) || [];

      setSinaisVitais(dadosFormatados);
    } catch (error) {
      console.error('Erro ao carregar dados:', error);
      toast({
        title: "Erro",
        description: "Erro ao carregar dados do banco.",
        variant: "destructive"
      });
    }
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({
      ...prev,
      [field]: value.toUpperCase() // Converter para maiúscula automaticamente
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.gmus || !formData.pressao || !formData.hgt || !formData.profissional) {
      toast({
        title: "Erro",
        description: "Por favor, preencha todos os campos obrigatórios.",
        variant: "destructive"
      });
      return;
    }

    try {
      const { data, error } = await (supabase as any)
        .from('sinais_vitais')
        .insert({
          gmus: formData.gmus.toUpperCase(),
          pressao: formData.pressao.toUpperCase(),
          hgt: formData.hgt.toUpperCase(),
          profissional: formData.profissional.toUpperCase()
        })
        .select()
        .single();

      if (error) {
        console.error('Erro ao salvar:', error);
        toast({
          title: "Erro",
          description: "Erro ao salvar os dados no banco.",
          variant: "destructive"
        });
        return;
      }

      // Recarregar os dados para atualizar a lista
      await carregarDados();
      setFormData({ gmus: '', pressao: '', hgt: '', profissional: '' });
      
      toast({
        title: "Sucesso",
        description: "Sinais vitais registrados com sucesso!",
      });
    } catch (error) {
      console.error('Erro ao salvar:', error);
      toast({
        title: "Erro",
        description: "Erro ao salvar os dados.",
        variant: "destructive"
      });
    }
  };

  const exportarDados = () => {
    const headers = ['DATA', 'G\'MUS', 'PRESSÃO', 'HGT', 'PROFISSIONAL'];
    const csvContent = [
      headers.join(','),
      ...sinaisVitais.map(sinal => 
        [sinal.data_hora, sinal.gmus, sinal.pressao, sinal.hgt, sinal.profissional].join(',')
      )
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', `sinais_vitais_${new Date().toISOString().split('T')[0]}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    toast({
      title: "Exportação Concluída",
      description: "Dados exportados com sucesso!",
    });
  };

  const removerRegistro = async (id: string) => {
    try {
      const { error } = await (supabase as any)
        .from('sinais_vitais')
        .delete()
        .eq('id', id);

      if (error) {
        console.error('Erro ao excluir:', error);
        toast({
          title: "Erro",
          description: "Erro ao excluir o registro.",
          variant: "destructive"
        });
        return;
      }

      // Recarregar os dados para atualizar a lista
      await carregarDados();
      toast({
        title: "Registro Removido",
        description: "Registro excluído com sucesso.",
      });
    } catch (error) {
      console.error('Erro ao excluir:', error);
      toast({
        title: "Erro",
        description: "Erro ao excluir o registro.",
        variant: "destructive"
      });
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="text-center py-8">
          <h1 className="text-4xl font-bold text-gray-800 mb-2 flex items-center justify-center gap-3">
            <Activity className="h-10 w-10 text-blue-600" />
            Sistema de Controle de Sinais Vitais
          </h1>
          <p className="text-gray-600 text-lg">Monitoramento e registro profissional de sinais vitais</p>
        </div>

        {/* Cards de Estatísticas */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <Card className="bg-gradient-to-r from-blue-500 to-blue-600 text-white">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-blue-100">Total de Registros</p>
                  <p className="text-2xl font-bold">{sinaisVitais.length}</p>
                </div>
                <Heart className="h-8 w-8 text-blue-200" />
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-gradient-to-r from-green-500 to-green-600 text-white">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-green-100">Hoje</p>
                  <p className="text-2xl font-bold">
                    {sinaisVitais.filter(s => s.data_hora.includes(new Date().toLocaleDateString('pt-BR'))).length}
                  </p>
                </div>
                <Activity className="h-8 w-8 text-green-200" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-r from-purple-500 to-purple-600 text-white">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-purple-100">Esta Semana</p>
                  <p className="text-2xl font-bold">
                    {sinaisVitais.filter(s => {
                      const dataRegistro = new Date(s.data_hora.split(',')[0].split('/').reverse().join('-'));
                      const hoje = new Date();
                      const inicioSemana = new Date(hoje.setDate(hoje.getDate() - hoje.getDay()));
                      return dataRegistro >= inicioSemana;
                    }).length}
                  </p>
                </div>
                <Droplets className="h-8 w-8 text-purple-200" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-r from-orange-500 to-orange-600 text-white">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-orange-100">Profissionais</p>
                  <p className="text-2xl font-bold">
                    {new Set(sinaisVitais.map(s => s.profissional)).size}
                  </p>
                </div>
                <User className="h-8 w-8 text-orange-200" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Formulário de Entrada */}
        <Card className="shadow-lg border-0">
          <CardHeader className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-t-lg">
            <CardTitle className="flex items-center gap-2 text-xl">
              <Plus className="h-6 w-6" />
              Registrar Novos Sinais Vitais
            </CardTitle>
          </CardHeader>
          <CardContent className="p-6">
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="gmus" className="text-sm font-medium text-gray-700">
                    G'MUS *
                  </Label>
                  <Input
                    id="gmus"
                    value={formData.gmus}
                    onChange={(e) => handleInputChange('gmus', e.target.value)}
                    placeholder="Ex: Cód G'mus"
                    className="border-gray-300 focus:border-blue-500 focus:ring-blue-500"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="pressao" className="text-sm font-medium text-gray-700">
                    PRESSÃO *
                  </Label>
                  <Input
                    id="pressao"
                    value={formData.pressao}
                    onChange={(e) => handleInputChange('pressao', e.target.value)}
                    placeholder="Ex: 120X80"
                    className="border-gray-300 focus:border-blue-500 focus:ring-blue-500"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="hgt" className="text-sm font-medium text-gray-700">
                    HGT *
                  </Label>
                  <Input
                    id="hgt"
                    value={formData.hgt}
                    onChange={(e) => handleInputChange('hgt', e.target.value)}
                    placeholder="Ex: 95 MG/DL"
                    className="border-gray-300 focus:border-blue-500 focus:ring-blue-500"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="profissional" className="text-sm font-medium text-gray-700">
                    PROFISSIONAL *
                  </Label>
                  <Input
                    id="profissional"
                    value={formData.profissional}
                    onChange={(e) => handleInputChange('profissional', e.target.value)}
                    placeholder="Nome do profissional"
                    className="border-gray-300 focus:border-blue-500 focus:ring-blue-500"
                  />
                </div>
              </div>

              <div className="flex justify-end pt-4">
                <Button 
                  type="submit" 
                  className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 px-8 py-2"
                >
                  <Plus className="h-4 w-4 mr-2" />
                  Registrar Sinais Vitais
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>

        {/* Tabela de Dados */}
        <Card className="shadow-lg border-0">
          <CardHeader className="bg-gradient-to-r from-gray-700 to-gray-800 text-white rounded-t-lg">
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2 text-xl">
                <Activity className="h-6 w-6" />
                Histórico de Sinais Vitais
              </CardTitle>
              <Button
                onClick={exportarDados}
                variant="secondary"
                className="bg-white text-gray-800 hover:bg-gray-100"
                disabled={sinaisVitais.length === 0}
              >
                <Download className="h-4 w-4 mr-2" />
                Exportar CSV
              </Button>
            </div>
          </CardHeader>
          <CardContent className="p-0">
            {sinaisVitais.length === 0 ? (
              <div className="text-center py-12 text-gray-500">
                <Activity className="h-12 w-12 mx-auto mb-4 text-gray-300" />
                <p className="text-lg">Nenhum registro encontrado</p>
                <p className="text-sm">Adicione o primeiro registro de sinais vitais</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-gray-50">
                      <TableHead className="font-semibold text-gray-700">DATA/HORA</TableHead>
                      <TableHead className="font-semibold text-gray-700">G'MUS</TableHead>
                      <TableHead className="font-semibold text-gray-700">PRESSÃO</TableHead>
                      <TableHead className="font-semibold text-gray-700">HGT</TableHead>
                      <TableHead className="font-semibold text-gray-700">PROFISSIONAL</TableHead>
                      <TableHead className="font-semibold text-gray-700">AÇÕES</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {sinaisVitais.map((sinal, index) => (
                      <TableRow 
                        key={sinal.id} 
                        className={index % 2 === 0 ? "bg-white" : "bg-gray-50"}
                      >
                        <TableCell className="font-medium">{sinal.data_hora}</TableCell>
                        <TableCell>{sinal.gmus}</TableCell>
                        <TableCell>{sinal.pressao}</TableCell>
                        <TableCell>{sinal.hgt}</TableCell>
                        <TableCell>{sinal.profissional}</TableCell>
                        <TableCell>
                          <Button
                            onClick={() => removerRegistro(sinal.id)}
                            variant="destructive"
                            size="sm"
                            className="text-xs"
                          >
                            Excluir
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Index;
